import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    // Get the current user data from Firebase Authentication
    User? user = FirebaseAuth.instance.currentUser;

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Profile',
          style: TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Colors.greenAccent,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Display User Information
            const Text(
              'User Information:',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text('Name: ${user?.displayName ?? "Not available"}'),
            Text('Email: ${user?.email ?? "Not available"}'),
            const SizedBox(height: 20),

            // Optionally, add buttons for updating profile data
            ElevatedButton(
              onPressed: () {
                // Handle Profile Update (e.g., navigate to an update page)
              },
              child: const Text('Update Profile'),
            ),
          ],
        ),
      ),
    );
  }
}
