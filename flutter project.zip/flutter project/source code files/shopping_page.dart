import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'cart_provider.dart'; // Import the CartProvider

class ShoppingPage extends StatelessWidget {
  final Map<String, List<Map<String, dynamic>>> categorizedInventory;

  const ShoppingPage({Key? key, required this.categorizedInventory})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Shopping Page',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: const Color.fromARGB(255, 86, 197, 142),
      ),
      body: Center(
        child: ListView.builder(
          shrinkWrap: true,
          itemCount: categorizedInventory.keys.length,
          itemBuilder: (context, index) {
            String category = categorizedInventory.keys.elementAt(index);
            List<Map<String, dynamic>> items = categorizedInventory[category]!;

            return Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                ...items
                    .map(
                      (item) => AnimatedContainer(
                        duration: const Duration(milliseconds: 500),
                        curve: Curves.easeInOut,
                        child: Card(
                          margin: const EdgeInsets.symmetric(
                              vertical: 8.0, horizontal: 16.0),
                          elevation: 4.0,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // Item Name at the Top with Green Background
                              Container(
                                width: double.infinity,
                                padding: const EdgeInsets.all(12.0),
                                color: Colors.green,
                                child: Text(
                                  item['name'],
                                  style: const TextStyle(
                                    fontSize: 18.0,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                              ListTile(
                                contentPadding: const EdgeInsets.symmetric(
                                    horizontal: 16.0, vertical: 12.0),
                                subtitle: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text('Price: ${item['price']}'),
                                    Text('Better for: ${item['betterFor']}'),
                                    const SizedBox(height: 8.0),
                                    Text(
                                      'Description: ${_getItemDescription(item['name'])}',
                                      textAlign: TextAlign.start,
                                      style: const TextStyle(
                                          fontSize: 14.0, color: Colors.grey),
                                    ),
                                  ],
                                ),
                                trailing: ElevatedButton(
                                  onPressed: () {
                                    // Add item to cart
                                    Provider.of<CartProvider>(context,
                                            listen: false)
                                        .addItemToCart(item);
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(
                                        content: Text(
                                            '${item['name']} added to cart!'),
                                        duration: const Duration(seconds: 2),
                                      ),
                                    );
                                  },
                                  style: ElevatedButton.styleFrom(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 12.0, vertical: 8.0),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(8.0),
                                    ),
                                    backgroundColor: Colors.tealAccent,
                                  ),
                                  child: const Text(
                                    'Buy',
                                    style: TextStyle(
                                      color: Colors.black87,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    )
                    .toList(),
              ],
            );
          },
        ),
      ),
    );
  }

  // Provide a detailed description based on the item name
  String _getItemDescription(String itemName) {
    switch (itemName) {
      case 'Toothpaste':
        return 'Toothpaste is used for cleaning teeth and improving oral hygiene. It helps prevent cavities, gum disease, and bad breath.';
      case 'Shampoo':
        return 'Shampoo is used to clean hair by removing oils, dirt, and dead skin cells. It keeps your hair healthy and nourished.';
      case 'Milk':
        return 'Milk is a nutritious drink, great for building strong bones and teeth due to its calcium content. It can be consumed or used in cooking.';
      // Add more items and their descriptions as needed
      default:
        return 'No description available.';
    }
  }
}
