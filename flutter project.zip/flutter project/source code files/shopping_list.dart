import 'package:flutter/material.dart';
import 'shopping_page.dart'; // Import the ShoppingPage file

class ShoppingListPage extends StatelessWidget {
  const ShoppingListPage({super.key});

  @override
  Widget build(BuildContext context) {
    // Sample shopping list items with additional details
    List<Map<String, dynamic>> shoppingListItems = [
      {'name': 'Toothpaste', 'price': '\$2.99', 'betterFor': 'Teeth cleaning'},
      {'name': 'Shampoo', 'price': '\$5.99', 'betterFor': 'Hair care'},
      {'name': 'Milk', 'price': '\$1.50', 'betterFor': 'Drinking or Cooking'},
      {'name': 'Coffee', 'price': '\$7.99', 'betterFor': 'Energy boost'},
      {'name': 'Rice', 'price': '\$3.49', 'betterFor': 'Cooking'},
      {'name': 'Detergent', 'price': '\$4.99', 'betterFor': 'Laundry'},
      {'name': 'Baking Powder', 'price': '\$2.29', 'betterFor': 'Baking'},
      {'name': 'Cooking Oil', 'price': '\$3.99', 'betterFor': 'Frying'},
      {'name': 'Pens', 'price': '\$1.99', 'betterFor': 'Writing'},
      {'name': 'Printer Ink', 'price': '\$19.99', 'betterFor': 'Printing'},
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Shopping List'),
        backgroundColor: Colors.greenAccent,
        elevation: 4.0,
      ),
      body: shoppingListItems.isEmpty
          ? const Center(
              child: Text(
                'Your shopping list is empty.',
                style: TextStyle(fontSize: 18, color: Colors.grey),
              ),
            )
          : ListView.builder(
              itemCount: shoppingListItems.length,
              itemBuilder: (context, index) {
                return _buildShoppingListItem(
                    context, shoppingListItems[index]);
              },
            ),
    );
  }

  // Build the individual list item and navigate on click
  Widget _buildShoppingListItem(
      BuildContext context, Map<String, dynamic> item) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
      elevation: 4.0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () {
          // Navigate to ShoppingPage and pass item details
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => ShoppingPage(
                categorizedInventory: {
                  item['name']: [
                    {
                      'name': item['name'],
                      'price': item['price'],
                      'betterFor': item['betterFor'],
                    }
                  ]
                },
              ),
            ),
          );
        },
        child: Container(
          padding: const EdgeInsets.all(16.0),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Colors.greenAccent, Colors.lightBlueAccent],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Row(
            children: [
              CircleAvatar(
                backgroundColor: Colors.white,
                radius: 24,
                child: Text(
                  item['name'][0],
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.green,
                  ),
                ),
              ),
              const SizedBox(width: 16.0),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      item['name'],
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 4.0),
                    Text(
                      item['betterFor'],
                      style: const TextStyle(
                        fontSize: 14,
                        color: Colors.white70,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 16.0),
              Text(
                item['price'],
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
