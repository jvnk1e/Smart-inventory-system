import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';

class ItemReviewPage extends StatefulWidget {
  const ItemReviewPage({super.key, required String itemName});

  @override
  _ItemReviewPageState createState() => _ItemReviewPageState();
}

class _ItemReviewPageState extends State<ItemReviewPage> {
  double _rating = 0.0;
  TextEditingController _reviewController = TextEditingController();
  TextEditingController _searchController = TextEditingController();
  List<Map<String, String>> _reviews = [];
  List<Map<String, dynamic>> _items = [
    {'name': 'Toothpaste', 'category': 'Personal'},
    {'name': 'Shampoo', 'category': 'Personal'},
    {'name': 'Conditioner', 'category': 'Personal'},
    {'name': 'Body Wash', 'category': 'Personal'},
    {'name': 'Deodorant', 'category': 'Personal'},
    {'name': 'Rice', 'category': 'Household'},
    {'name': 'Toilet Paper', 'category': 'Household'},
    {'name': 'Cleaning Detergent', 'category': 'Household'},
    {'name': 'Printer Ink', 'category': 'Small Business'},
    {'name': 'Stapler', 'category': 'Small Business'},
  ];

  List<Map<String, dynamic>> _filteredItems = [];

  @override
  void initState() {
    super.initState();
    _filteredItems = _items;
  }

  void _submitReview(String itemName) {
    if (_reviewController.text.isNotEmpty && _rating > 0) {
      setState(() {
        _reviews.add({
          'item': itemName,
          'rating': _rating.toString(),
          'review': _reviewController.text,
        });
      });

      _reviewController.clear();
      _rating = 0.0;

      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Review submitted for $itemName')));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Please add a review and rating')));
    }
  }

  void _filterItems() {
    setState(() {
      _filteredItems = _items
          .where((item) => item['name']!
              .toLowerCase()
              .contains(_searchController.text.toLowerCase()))
          .toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.greenAccent, // Updated color
        title: Text('Item Review and Rating',
            style: TextStyle(fontWeight: FontWeight.bold)),
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Search Bar with updated color
            TextField(
              controller: _searchController,
              decoration: InputDecoration(
                labelText: 'Search for an item',
                labelStyle:
                    TextStyle(color: Colors.greenAccent), // Updated color
                prefixIcon: Icon(Icons.search,
                    color: Colors.greenAccent), // Updated color
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(
                      color: Colors.greenAccent, width: 1.5), // Updated color
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(
                      color: Colors.greenAccent, width: 2), // Updated color
                ),
              ),
              onChanged: (value) {
                _filterItems();
              },
            ),
            SizedBox(height: 20),
            // List of Items with better padding and spacing
            Expanded(
              child: ListView.builder(
                itemCount: _filteredItems.length,
                itemBuilder: (context, index) {
                  String itemName = _filteredItems[index]['name'];
                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8.0),
                    child: Card(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      elevation: 3,
                      child: ListTile(
                        contentPadding: EdgeInsets.symmetric(
                            horizontal: 16.0, vertical: 12.0),
                        title: Text(itemName,
                            style: TextStyle(
                                fontSize: 18, fontWeight: FontWeight.w500)),
                        trailing: IconButton(
                          icon: Icon(Icons.rate_review,
                              color: Colors.greenAccent), // Updated color
                          onPressed: () {
                            _showRatingDialog(itemName);
                          },
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showRatingDialog(String itemName) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Rate $itemName',
              style: TextStyle(fontWeight: FontWeight.bold)),
          content: Padding(
            padding: const EdgeInsets.only(top: 10.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                RatingBar.builder(
                  initialRating: _rating,
                  minRating: 1,
                  direction: Axis.horizontal,
                  itemCount: 5,
                  itemSize: 40,
                  itemBuilder: (context, _) =>
                      Icon(Icons.star, color: Colors.amber),
                  onRatingUpdate: (rating) {
                    setState(() {
                      _rating = rating;
                    });
                  },
                ),
                SizedBox(height: 20),
                TextField(
                  controller: _reviewController,
                  decoration: InputDecoration(
                    labelText: 'Write a review...',
                    labelStyle:
                        TextStyle(color: Colors.greenAccent), // Updated color
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                _submitReview(itemName);
                Navigator.pop(context);
              },
              child: Text('Submit',
                  style: TextStyle(color: Colors.greenAccent)), // Updated color
            ),
          ],
        );
      },
    );
  }
}
