import 'package:flutter/material.dart';

class CartProvider with ChangeNotifier {
  List<Map<String, dynamic>> _cartItems = [];

  List<Map<String, dynamic>> get cartItems => _cartItems;

  // Add item to the cart
  void addItemToCart(Map<String, dynamic> item) {
    _cartItems.add(item);
    notifyListeners();
  }

  // Remove item from the cart
  void removeItemFromCart(Map<String, dynamic> item) {
    _cartItems.remove(item);
    notifyListeners();
  }
}
