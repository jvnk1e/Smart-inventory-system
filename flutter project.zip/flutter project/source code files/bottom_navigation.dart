import 'package:flutter/material.dart';
import 'stats.dart'; // Example of stats page

class BottomNavigation extends StatelessWidget {
  final int selectedIndex;
  final Function(int) onItemTapped;

  const BottomNavigation({
    super.key,
    required this.selectedIndex,
    required this.onItemTapped,
  });

  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      currentIndex: selectedIndex,
      onTap: (index) {
        onItemTapped(index); // Calls the function to handle index change
        if (index == 1) {
          // Navigate to Stats page when Stats tab is tapped
          Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => const StatsPage(
                      categorizedInventory: {},
                    )),
          );
        }
      },
      items: const [
        BottomNavigationBarItem(
          icon: Icon(Icons.inventory),
          label: 'Inventory',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.analytics),
          label: 'Stats',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.shopping_cart),
          label: 'Shopping List',
        ),
      ],
    );
  }
}
