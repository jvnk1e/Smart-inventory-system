import 'package:flutter/material.dart';

class ProductDetailsPage extends StatelessWidget {
  final Map<String, dynamic> product;
  final Function(Map<String, dynamic>) onRemove;

  const ProductDetailsPage({
    super.key,
    required this.product,
    required this.onRemove,
    required Map<String, dynamic> item,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Product Details'),
        backgroundColor: Colors.greenAccent, // Green app bar
      ),
      body: Container(
        // Apply gradient background to the body
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Colors.white,
              Colors.lightGreen.shade50
            ], // Gradient from white to light green
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Center(
            // Center the entire content
            child: Card(
              color: Colors.white,
              elevation: 5.0,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  mainAxisSize:
                      MainAxisSize.min, // Ensures content takes minimal space
                  crossAxisAlignment:
                      CrossAxisAlignment.center, // Centering horizontally
                  children: [
                    Text(
                      'Product Name: ${product['name']}',
                      style: const TextStyle(
                          fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    // Center the expiry date text
                    Text(
                      'Expiry Date: ${product['expiryDate']}',
                      style: const TextStyle(fontSize: 16),
                      textAlign: TextAlign
                          .center, // Ensuring the expiry date is centered
                    ),
                    const SizedBox(height: 8),
                    Text('Usage: ${product['usageCount']}'),
                    const SizedBox(height: 20),
                    // Centering the Remove button
                    ElevatedButton(
                      onPressed: () {
                        onRemove(product); // Call the remove function
                        Navigator.pop(context); // Navigate back after removal
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor:
                            Colors.greenAccent, // Green button color
                      ),
                      child: const Text('Remove Product'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
