import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'app_drawer.dart';
import 'bottom_navigation.dart';
import 'product_details.dart'; // Import ProductDetailsPage
import 'add_item_page.dart'; // Import AddItemPage if you have one
import 'stats.dart'; // Import the Stats page
import 'shopping_list.dart'; // Import ShoppingListPage if you have it

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final Map<String, List<Map<String, dynamic>>> categorizedInventory = {
    'Personal': [
      {'name': 'Toothpaste', 'expiryDate': '2024-12-31', 'usageCount': 1},
      {'name': 'Shampoo', 'expiryDate': '2025-01-15', 'usageCount': 3},
      {'name': 'Conditioner', 'expiryDate': '2025-02-01', 'usageCount': 2},
      {'name': 'Body Wash', 'expiryDate': '2025-03-10', 'usageCount': 1},
      {'name': 'Deodorant', 'expiryDate': '2025-05-15', 'usageCount': 4},
      {'name': 'Toothbrush', 'expiryDate': '2024-12-15', 'usageCount': 2},
      {'name': 'Hand Wash', 'expiryDate': '2025-01-25', 'usageCount': 1},
      {'name': 'Face Cream', 'expiryDate': '2025-04-10', 'usageCount': 3},
      {'name': 'Sunscreen', 'expiryDate': '2025-06-01', 'usageCount': 1},
      {'name': 'Lip Balm', 'expiryDate': '2025-07-01', 'usageCount': 0},
      {'name': 'Shaving Cream', 'expiryDate': '2025-02-20', 'usageCount': 0},
    ],
    'Household': [
      {'name': 'Rice', 'expiryDate': '2025-06-01', 'usageCount': 0},
      {'name': 'Toilet Paper', 'expiryDate': '2025-03-10', 'usageCount': 2},
      {
        'name': 'Cleaning Detergent',
        'expiryDate': '2025-05-15',
        'usageCount': 1
      },
      {'name': 'Broom', 'expiryDate': '2025-07-20', 'usageCount': 0},
      {'name': 'Mop', 'expiryDate': '2025-08-10', 'usageCount': 2},
      {'name': 'Dish Soap', 'expiryDate': '2025-04-10', 'usageCount': 1},
      {'name': 'Sponges', 'expiryDate': '2025-03-01', 'usageCount': 1},
      {'name': 'Garbage Bags', 'expiryDate': '2025-09-10', 'usageCount': 5},
      {'name': 'Laundry Powder', 'expiryDate': '2025-01-01', 'usageCount': 3},
      {
        'name': 'Washing Machine Cleaner',
        'expiryDate': '2025-02-01',
        'usageCount': 1
      },
      {'name': 'Iron', 'expiryDate': '2025-12-31', 'usageCount': 1},
    ],
    'Small Business': [
      {'name': 'Printer Ink', 'expiryDate': '2025-03-10', 'usageCount': 0},
      {'name': 'Stapler', 'expiryDate': '2024-12-20', 'usageCount': 1},
      {'name': 'Paper Clips', 'expiryDate': '2025-06-15', 'usageCount': 10},
      {'name': 'Notebooks', 'expiryDate': '2025-07-10', 'usageCount': 5},
      {'name': 'Pens', 'expiryDate': '2025-01-10', 'usageCount': 7},
      {'name': 'Markers', 'expiryDate': '2025-03-01', 'usageCount': 8},
      {'name': 'Folders', 'expiryDate': '2025-08-15', 'usageCount': 2},
      {'name': 'Sticky Notes', 'expiryDate': '2025-05-01', 'usageCount': 3},
      {'name': 'Calculator', 'expiryDate': '2025-12-20', 'usageCount': 0},
      {'name': 'Paper', 'expiryDate': '2025-09-01', 'usageCount': 15},
      {'name': 'Tape', 'expiryDate': '2025-04-01', 'usageCount': 4},
    ],
  };

  String selectedCategory = 'Personal';
  final DateFormat dateFormat = DateFormat('yyyy-MM-dd');
  int _selectedIndex = 0;

  late AnimationController _controller;
  String searchQuery = "";

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  bool _isExpired(String expiryDate) {
    DateTime currentDate = DateTime.now();
    DateTime itemExpiryDate = dateFormat.parse(expiryDate);
    return itemExpiryDate.isBefore(currentDate);
  }

  void _removeItem(String category, int index) {
    setState(() {
      categorizedInventory[category]?.removeAt(index); // Removes the item
    });
  }

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(seconds: 1),
      vsync: this,
    );
    _controller.forward();
  }

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> currentInventory =
        categorizedInventory[selectedCategory] ?? [];
    final filteredInventory = searchQuery.isEmpty
        ? currentInventory
        : currentInventory.where((item) {
            return item['name']
                    .toLowerCase()
                    .contains(searchQuery.toLowerCase()) ||
                item['expiryDate'].contains(searchQuery);
          }).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Inventory Home',
          style: TextStyle(
            fontWeight: FontWeight.bold, // Bold app bar text
          ),
        ),
        backgroundColor: Colors.greenAccent,
      ),
      drawer: const AppDrawer(),
      body: Container(
        color: Colors.grey[200], // Background color like a login page
        child: _selectedIndex == 0
            ? Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12.0, vertical: 5.0),
                      decoration: BoxDecoration(
                        color: Colors.greenAccent[100],
                        borderRadius: BorderRadius.circular(15.0),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.5),
                            blurRadius: 8.0,
                            spreadRadius: 1.0,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(
                          maxWidth: 250, // Reduced width for the dropdown
                        ),
                        child: DropdownButton<String>(
                          value: selectedCategory,
                          onChanged: (String? newValue) {
                            setState(() {
                              selectedCategory = newValue!;
                              searchQuery =
                                  ""; // Reset search on category change
                            });
                          },
                          items: categorizedInventory.keys
                              .map<DropdownMenuItem<String>>((String category) {
                            return DropdownMenuItem<String>(
                              value: category,
                              child: Center(
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(
                                      vertical: 10.0, horizontal: 16.0),
                                  child: Text(
                                    category,
                                    style: const TextStyle(
                                      fontSize: 16.0,
                                      fontWeight: FontWeight.w500,
                                      color: Colors.black,
                                    ),
                                  ),
                                ),
                              ),
                            );
                          }).toList(),
                          icon: const Icon(Icons.arrow_drop_down,
                              color: Colors.black),
                          isExpanded: true,
                          underline: const SizedBox(),
                          dropdownColor: Colors.greenAccent[100],
                          elevation: 8,
                          style: const TextStyle(
                              color: Colors.black), // Text color in dropdown
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: TextField(
                      decoration: InputDecoration(
                        hintText: 'Search inventory by name or expiry date',
                        prefixIcon: const Icon(Icons.search),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                        filled: true,
                        fillColor: Colors.white,
                      ),
                      onChanged: (value) {
                        setState(() {
                          searchQuery = value;
                        });
                      },
                    ),
                  ),
                  Expanded(
                    child: filteredInventory.isEmpty
                        ? const Center(
                            child: Text(
                              'No items match your search.',
                              style:
                                  TextStyle(fontSize: 18, color: Colors.grey),
                            ),
                          )
                        : ListView.builder(
                            itemCount: filteredInventory.length,
                            itemBuilder: (context, index) {
                              var item = filteredInventory[index];
                              bool isExpired = _isExpired(item['expiryDate']);
                              return Padding(
                                padding:
                                    const EdgeInsets.symmetric(vertical: 4.0),
                                child: Card(
                                  elevation: 4.0,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  color:
                                      isExpired ? Colors.red[50] : Colors.white,
                                  child: ListTile(
                                    leading: Icon(
                                      isExpired
                                          ? Icons.remove_circle_outline
                                          : Icons.check_circle_outline,
                                      color:
                                          isExpired ? Colors.red : Colors.green,
                                    ),
                                    title: Text(
                                      item['name'],
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 16,
                                        color: isExpired
                                            ? Colors.red
                                            : Colors.black,
                                      ),
                                    ),
                                    subtitle: Text(
                                      'Expiry Date: ${item['expiryDate']} | Usage: ${item['usageCount']}',
                                      style: const TextStyle(fontSize: 12),
                                    ),
                                    onTap: () {
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (context) =>
                                              ProductDetailsPage(
                                            product: item,
                                            onRemove: (product) {
                                              _removeItem(
                                                  selectedCategory, index);
                                            },
                                            item: const {},
                                          ),
                                        ),
                                      );
                                    },
                                    trailing: IconButton(
                                      icon: const Icon(Icons.delete),
                                      onPressed: () {
                                        _removeItem(selectedCategory, index);
                                      },
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
                  ),
                ],
              )
            : _selectedIndex == 1
                ? const StatsPage(
                    categorizedInventory: {},
                  )
                : const ShoppingListPage(),
      ),
      bottomNavigationBar: Container(
        color: Colors.greenAccent,
        child: BottomNavigationBar(
          currentIndex: _selectedIndex,
          onTap: _onItemTapped,
          selectedItemColor: Colors.white,
          unselectedItemColor: Colors.black,
          backgroundColor: Colors.greenAccent,
          elevation: 8.0,
          items: const [
            BottomNavigationBarItem(
              icon: Icon(Icons.home),
              label: 'Home',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.analytics),
              label: 'Stats',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.list),
              label: 'Shopping List',
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }
}
