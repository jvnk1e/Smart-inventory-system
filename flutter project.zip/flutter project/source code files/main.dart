import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart'; // Import Firebase
import 'package:provider/provider.dart'; // Import Provider package
import 'splash_screen.dart'; // Import the SplashScreen
import 'cart_provider.dart'; // Import the CartProvider
import 'shopping_page.dart'; // Import the ShoppingPage

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(); // Initialize Firebase
  runApp(
    ChangeNotifierProvider(
      create: (context) =>
          CartProvider(), // Provide CartProvider to the widget tree
      child: const MyApp(), // Run MyApp within the provider
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Smart Inventory Hub',
      theme: ThemeData(
        primarySwatch:
            Colors.green, // Change to green to match your app's theme
        visualDensity: VisualDensity.adaptivePlatformDensity,
        fontFamily: 'Roboto', // Optional: Set a default font family
      ),
      home: const SplashScreen(), // Start with the SplashScreen
    );
  }
}
