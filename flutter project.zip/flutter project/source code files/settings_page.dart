import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'home.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  // Helper function to display user email and password
  void _showEmailAndPassword(BuildContext context) {
    User? user = FirebaseAuth.instance.currentUser;
    String email = user?.email ?? "No email found";
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Email & Password"),
        content: Text("Email: $email\nPassword: Hidden for security"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("OK"),
          ),
        ],
      ),
    );
  }

  // Function to navigate to Authentication settings
  void _showAuthenticationSettings(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Authentication"),
        content: const Text(
          "Manage two-factor authentication, login methods, and more.",
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("OK"),
          ),
        ],
      ),
    );
  }

  // Function to open Advertise Tools (Placeholder)
  void _openAdvertiseTools(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Advertise Tools"),
        content: const Text(
          "Explore advertising tools to promote your business.",
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("OK"),
          ),
        ],
      ),
    );
  }

  // Function to manage Favorites
  void _manageFavorites(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Favorites"),
        content: const Text("View and manage your favorite items or lists."),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("OK"),
          ),
        ],
      ),
    );
  }

  // Function to handle Communities
  void _handleCommunities(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Communities"),
        content: const Text(
          "Join communities and connect with others to share resources.",
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("OK"),
          ),
        ],
      ),
    );
  }

  // Function to manage Account Privacy
  void _managePrivacySettings(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Account Privacy"),
        content: const Text("Update your privacy settings."),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("OK"),
          ),
        ],
      ),
    );
  }

  // Function to manage Notifications
  void _manageNotifications(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Notifications"),
        content: const Text("Set your notification preferences."),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("OK"),
          ),
        ],
      ),
    );
  }

  // Function to display Help information
  void _displayHelp(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Help"),
        content: const Text("Access support and app documentation."),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("OK"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Settings',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
        backgroundColor: Colors.greenAccent,
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            // Email & Password Section
            Card(
              elevation: 3,
              margin: const EdgeInsets.symmetric(vertical: 8.0),
              child: ListTile(
                title: const Text('Email & Password'),
                subtitle: const Text('Manage your email and password settings'),
                leading: const Icon(Icons.email),
                onTap: () => _showEmailAndPassword(context),
              ),
            ),

            // Authentication Section
            Card(
              elevation: 3,
              margin: const EdgeInsets.symmetric(vertical: 8.0),
              child: ListTile(
                title: const Text('Authentication'),
                subtitle: const Text('View and manage authentication settings'),
                leading: const Icon(Icons.lock),
                onTap: () => _showAuthenticationSettings(context),
              ),
            ),

            // Advertise Tools Section
            Card(
              elevation: 3,
              margin: const EdgeInsets.symmetric(vertical: 8.0),
              child: ListTile(
                title: const Text('Advertise Tools'),
                subtitle: const Text('Explore tools for advertising'),
                leading: const Icon(Icons.campaign),
                onTap: () => _openAdvertiseTools(context),
              ),
            ),

            // Favorites Section
            Card(
              elevation: 3,
              margin: const EdgeInsets.symmetric(vertical: 8.0),
              child: ListTile(
                title: const Text('Favorites'),
                subtitle: const Text('Manage your favorite items or lists'),
                leading: const Icon(Icons.favorite),
                onTap: () => _manageFavorites(context),
              ),
            ),

            // Communities Section
            Card(
              elevation: 3,
              margin: const EdgeInsets.symmetric(vertical: 8.0),
              child: ListTile(
                title: const Text('Communities'),
                subtitle:
                    const Text('Connect with communities and share resources'),
                leading: const Icon(Icons.group),
                onTap: () => _handleCommunities(context),
              ),
            ),

            // Account Privacy Section
            Card(
              elevation: 3,
              margin: const EdgeInsets.symmetric(vertical: 8.0),
              child: ListTile(
                title: const Text('Account Privacy'),
                subtitle: const Text('Manage your privacy settings'),
                leading: const Icon(Icons.privacy_tip),
                onTap: () => _managePrivacySettings(context),
              ),
            ),

            // Notifications Section
            Card(
              elevation: 3,
              margin: const EdgeInsets.symmetric(vertical: 8.0),
              child: ListTile(
                title: const Text('Notifications'),
                subtitle: const Text('Set your notification preferences'),
                leading: const Icon(Icons.notifications),
                onTap: () => _manageNotifications(context),
              ),
            ),

            // Help Section
            Card(
              elevation: 3,
              margin: const EdgeInsets.symmetric(vertical: 8.0),
              child: ListTile(
                title: const Text('Help'),
                subtitle: const Text('Get support and app documentation'),
                leading: const Icon(Icons.help_outline),
                onTap: () => _displayHelp(context),
              ),
            ),

            // Go Back to Home Button
            Card(
              elevation: 3,
              margin: const EdgeInsets.symmetric(vertical: 8.0),
              color: Colors.greenAccent.shade100, // Updated color
              child: ListTile(
                title: const Text(
                  'Go Back to Home',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                leading: const Icon(
                  Icons.home,
                  color: Colors.green, // Matches the theme
                ),
                onTap: () {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => const HomePage()),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
