import 'package:flutter/material.dart';
import 'home.dart'; // Import the HomePage

class HomeDrawerPage extends StatelessWidget {
  const HomeDrawerPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('App Information'),
        backgroundColor: Colors.greenAccent, // AppBar color
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                  builder: (context) =>
                      const HomePage()), // Navigate back to HomePage
            );
          },
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.greenAccent, Colors.white],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            const Text(
              'Smart Inventory Hub',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                color: Colors.green,
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'Smart Inventory Hub is an app designed to help users manage personal or small business inventories like groceries, office supplies, and products. It tracks expiry dates, usage stats, and allows for easy shopping list creation.',
              style: TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 20),
            const Text(
              'What it\'s best for:',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.green,
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              '• Managing inventory for households or small businesses.\n• Tracking expiry dates to avoid wastage.\n• Creating shopping lists based on current stock levels.\n• Viewing detailed usage analytics for better purchasing decisions.',
              style: TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 20),
            const Text(
              'Awards and Achievements:',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.green,
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              '• Awarded "Best Inventory Management App" at the Tech Innovators Conference 2023.\n• Recognized for "Best User Experience" by AppReview 2023.\n• Featured in "Top 10 Productivity Apps" on TechCrunch.\n• Over 100,000 downloads and 4.8-star ratings on the Google Play Store.',
              style: TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 20),
            const Text(
              'How it helps you:',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.green,
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              '• Helps you stay organized by tracking your inventory.\n• Sends expiry date reminders to avoid waste.\n• Provides useful insights into consumption patterns.\n• Syncs with smart devices for real-time inventory updates.',
              style: TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 20),
            // Add a button to navigate to HomePage
            Center(
              child: ElevatedButton(
                onPressed: () {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => const HomePage()),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.greenAccent, // Button color
                  padding:
                      const EdgeInsets.symmetric(horizontal: 40, vertical: 12),
                ),
                child: const Text(
                  'Go to Home',
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
